import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api/shipments';

const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

export async function getShipments() {
  try {
    const response = await axios.get(API_BASE_URL, { headers: getAuthHeaders() });
    return response.data;
  } catch (error) {
    console.error('Failed to fetch shipments:', error);
    return [];
  }
}

export async function createShipment(shipment) {
  try {
    const response = await axios.post(API_BASE_URL, shipment, { headers: getAuthHeaders() });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to create shipment');
  }
}
