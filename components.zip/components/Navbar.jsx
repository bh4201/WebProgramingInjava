import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-lg py-3">
      <div className="container">
        <Link className="navbar-brand fw-bold fs-3" to="/">Logistics Tracker</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto text-center">
            <li className="nav-item mx-2"><NavLink to="/" className="nav-link" end>Home</NavLink></li>
            <li className="nav-item mx-2"><NavLink to="/signup" className="nav-link">Sign Up</NavLink></li>
            <li className="nav-item mx-2"><NavLink to="/login" className="nav-link">Login</NavLink></li>
            <li className="nav-item mx-2"><NavLink to="/admin" className="nav-link">Admin Dashboard</NavLink></li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
