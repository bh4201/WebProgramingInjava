import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Footer = () => (
  <footer className="bg-dark text-white mt-5 py-4">
    <div className="container text-center">
      <h5>Logistics Tracker &copy; 2025</h5>
      <small>All rights reserved.</small>
    </div>
  </footer>
);

export default Footer;
