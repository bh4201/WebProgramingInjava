import React, { useEffect, useState } from 'react';
import { getShipments } from '../services/shipmentService';

const ShipmentList = () => {
  const [shipments, setShipments] = useState([]);

  useEffect(() => {
    fetchShipments();
  }, []);

  async function fetchShipments() {
    const data = await getShipments();
    setShipments(data);
  }

  if (shipments.length === 0) {
    return <p>No shipments found.</p>;
  }

  return (
    <div>
      <h4>Shipment List</h4>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Tracking Number</th>
            <th>Destination</th>
          </tr>
        </thead>
        <tbody>
          {shipments.map(s => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.trackingNumber}</td>
              <td>{s.destination}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ShipmentList;
