import React, { useState } from 'react';
import { signup } from '../services/authService';

const Signup = () => {
  const [user, setUser] = useState({ username: '', password: '' });
  const [message, setMessage] = useState('');

  const handleChange = e => setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    const res = await signup(user);
    if (res.success !== false) {
      setMessage('Signup successful! Please login.');
      setUser({ username: '', password: '' });
    } else {
      setMessage(res.message || 'Signup failed');
    }
  };

  return (
    <div className="container mt-5" style={{ maxWidth: '400px' }}>
      <h2>Sign Up</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Username</label>
          <input name="username" value={user.username} onChange={handleChange} required className="form-control" />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" name="password" value={user.password} onChange={handleChange} required className="form-control" />
        </div>
        <button type="submit" className="btn btn-primary w-100">Sign Up</button>
      </form>
    </div>
  );
};

export default Signup;
