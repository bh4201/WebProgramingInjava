import React from 'react';

const Home = () => (
  <div className="container mt-5 text-center">
    <h1>Welcome to Logistics Tracker!</h1>
    <p>Your one-stop app to track shipments efficiently.</p>
  </div>
);

export default Home;
