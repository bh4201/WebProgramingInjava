import React, { useState } from 'react';
import { createShipment } from '../services/shipmentService';

const ShipmentForm = ({ onAdd }) => {
  const [shipment, setShipment] = useState({ trackingNumber: '', destination: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleChange = e => setShipment({ ...shipment, [e.target.name]: e.target.value });

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await createShipment(shipment);
      setSuccess('Shipment added successfully!');
      setShipment({ trackingNumber: '', destination: '' });
      if(onAdd) onAdd(); // Refresh shipment list
    } catch (err) {
      setError(err.message || 'Failed to add shipment');
    }
  };

  return (
    <div className="mb-4">
      <h4>Add Shipment</h4>
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      <form onSubmit={handleSubmit} className="row g-3">
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Tracking Number"
            name="trackingNumber"
            value={shipment.trackingNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Destination"
            name="destination"
            value={shipment.destination}
            onChange={handleChange}
            required
          />
        </div>
        <div className="col-12">
          <button type="submit" className="btn btn-primary w-100">Add Shipment</button>
        </div>
      </form>
    </div>
  );
};

export default ShipmentForm;
