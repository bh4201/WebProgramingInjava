import React from 'react';
import ShipmentForm from './ShipmentForm';
import ShipmentList from './ShipmentList';

const AdminDashboard = () => {
  const [refresh, setRefresh] = React.useState(false);

  const handleAddShipment = () => setRefresh(!refresh);

  return (
    <div className="container mt-5">
      <h2>Admin Dashboard</h2>
      <ShipmentForm onAdd={handleAddShipment} />
      <ShipmentList key={refresh} />
    </div>
  );
};

export default AdminDashboard;
