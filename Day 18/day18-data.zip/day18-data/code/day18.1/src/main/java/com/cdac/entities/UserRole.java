package com.cdac.entities;

public enum UserRole {
	CUSTOMER, ADMIN, DELIVERY_PERSON
}
