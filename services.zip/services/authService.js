import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api/auth';

export async function signup(user) {
  try {
    const response = await axios.post(`${API_BASE_URL}/signup`, user);
    return response.data;
  } catch (error) {
    return { success: false, message: error.response?.data?.message || error.message };
  }
}

export async function login(credentials) {
  try {
    const response = await axios.post(`${API_BASE_URL}/login`, credentials);
    return response.data;
  } catch (error) {
    return { success: false, message: error.response?.data?.message || error.message };
  }
}
