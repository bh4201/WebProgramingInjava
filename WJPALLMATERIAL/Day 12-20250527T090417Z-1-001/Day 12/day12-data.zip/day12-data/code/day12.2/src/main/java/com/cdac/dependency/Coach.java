package com.cdac.dependency;

public interface Coach {

    String getDailyWorkout();
}
