package com.cdac.entities;


public enum UserRole {
	CUSTOMER, MANAGER, ADMIN,DELIVERY_PERSON
}
